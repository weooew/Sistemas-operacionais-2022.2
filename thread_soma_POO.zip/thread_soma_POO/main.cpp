#include <string>
#include <iostream>
#include <thread>

using namespace std;

int soma(int a, int b){
	int soma = a+b;
}

class Teste{
public:
	Teste();
	void tarefa(int parametroA, int parametroB);
	void imprimirResultado();
	
private:
	int resultado;
};

Teste::Teste(){
	resultado = 0;
}

void Teste::tarefa(int parametroA, int parametroB){
	resultado = soma(parametroA, parametroB);
}

void Teste::imprimirResultado(){
	cout << "Resultado: " << resultado << endl;
}

int main()
{
    Teste teste1;
    shared_ptr<Teste> teste2 (new Teste);
    
    thread t1(&Teste::tarefa, &teste1, 30, 30);
    thread t2(&Teste::tarefa, teste2, 20, 1);
    
    t1.join();
    t2.join();
    
    teste1.imprimirResultado();
    teste2->imprimirResultado();
    return 0;
}























