#include <iostream>
#include <memory>
#include <thread>

using namespace std;

void soma(int a, int b){
	int s;
	s = a+b;
	cout << "Aqui eh a soma da thread: " << s << endl;
	
}

int main()
{
    
    thread t1(soma, 10, 20);
    
    cout << "Uma mensagem do Main" << endl;
    
    t1.join();
    return 0;
}
