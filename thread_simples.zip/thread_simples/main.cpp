#include <string>
#include <iostream>
#include <thread>


using namespace std;

void tarefa(string msg){
    cout << "Aqui eh uma mensagem da thread: " << msg << endl;
}

int main()
{
    thread t1(tarefa, "Olá da thread");

    //....

    cout << "Uma mensagem do Main" << endl;

    t1.join();
    return 0;
}
